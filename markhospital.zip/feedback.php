<?php include('includes/header.php'); ?>
        
        <div class="title-section dark-bg">
            
            <div class="grid-container grid-x grid-padding-x">

                <div class="small-12 cell">
                    <h1>Feedback Form</h1>
                </div><!-- Top Row /-->

               

            </div><!-- Row /-->
            
        </div>
		<!-- Title Section Ends /-->
        
        <div class="appointment-page form-section dark-bg grey-bg">
        	
        	<div class="grid-container grid-x grid-padding-x">

           <iframe src="https://docs.google.com/forms/d/e/1FAIpQLSdZn0Qi1o9ueYF4QUtQxTY0FWPuIanw2naX24Lk-Q28wVL0Rg/viewform?embedded=true" width="2000" height="910" frameborder="" marginheight="0" marginwidth="0">Loading…</iframe>
            	
                <!--
            	<div class="large-8 medium-offset-2 large-offset-2 medium-8 small-12 cell">
                	<div class="form">
                    	<h2>Contact Us</h2>
                        <p>Want to book an appointment with us? Fill up the form below to get appointment.</p>
                    	<div class="appointment-form">
                        <form action="https://www.webfulcreations.com/html-templates/dermatology/email_processor.php" method="post">
                            <div class="grid-container grid-x grid-padding-x">
                                <div class="medium-6 small-12 cell">
                                    <label>
                                        Your Full Name *
                                        <input type="text" name="your_name" placeholder="Name">
                                    </label>    
                                 </div>
                                 <div class="medium-6 small-12 cell">
                                    <label>
                                        Your Phone# *   
                                        <input type="text" name="your_phone" placeholder="Phone">
                                    </label>
                                 </div>
                                 <div class="medium-6 small-12 cell">
                                    <label>
                                        Your Email *
                                        <input type="text" name="your_email" placeholder="Email">
                                    </label>    
                                </div>
                                <div class="medium-6 small-12 cell">
                                    <label>
                                        Preffered Date *
                                        <input type="text" name="your_date" placeholder="">
                                    </label>    
                                </div>
                                <div class="medium-12 cell">
                                    <label>
                                        Select dpcktor
                                        <select name="select_doctor">
                                            <option value="Anyone">Select Gardener</option>
                                            <option value="dr john">Vet 1</option>
                                            <option value="dr vale">Vet 2</option>
                                        </select>
                                    </label>    
                                </div>
                                <div class="medium-12 cell">
                                    <label>
                                        Select Service
                                        <select name="select_service">
                                            <option value="service empty">Select Service</option>
                                            <option value="Service first">Service 1</option>
                                            <option value="service two">Service 2</option>
                                        </select>
                                    </label>    
                                </div>
                                <div class="medium-12 cell">
                                    <label>
                                        Your message
                                        <textarea name="your_message" placeholder="Your message" rows="4"></textarea>
                                    </label>    
                                </div>
                                
                                <div class="medium-12 cell">
                                	<input type="hidden" name="appointment_form" value="YES" />
                                    <button class="primary button" type="submit">Send Form!</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    -->
                    <!-- contact Form ends here. -->
                    </div><!-- Form/-->
                    <div class="clearfix"></div>
                </div><!-- cell /-->
                
            </div><!-- Grid Container /-->
            
        </div>
        <!-- Form Section /-->
        
<?php include('includes/footer.php'); ?>  