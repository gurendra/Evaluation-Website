<?php include('includes/header.php'); ?>

        <div class="title-section dark-bg">
            
            <div class="grid-container grid-x grid-padding-x">

                <div class="small-12 cell">
                    <h1>CAREERS</h1>
                </div><!-- Top Row /-->

                <div class="small-12 cell">
                    <ul class="breadcrumbs">
                        
                        
                    </ul><!-- Breadcrumbs /-->
                </div><!-- Bottom Row /-->

            </div><!-- Row /-->
            
        </div>
		<!-- Title Section Ends /-->
	    <div class="testimonials testimonial-page grey-bg">
        	
            <div class="padding-between-inner-pags">
                <div class="grid-container grid-x grid-padding-x">
                    
                    <div class="large-9 medium-7 small-12 cell">
                        
                        <div class="testimonial grid-container grid-x grid-padding-x grid-padding-y">

                         <div class="large-12 medium-12 small-12  cell">
                                <div class="testimonial-text">
                                    <h1>Our Opening..</h1>
                                    
                                    <p>At MARK Hospital we underscore on Patient Care first and We accept that our employees assume an imperative job in conveying the equivalent. MARK Hospital isn't just dedicated to making and keeping up a workplace where staff can utilize their aptitudes, talents, and capacities to convey top-notch medicinal services and administration to patients, staff, and guests. </p>
                                    
                                </div><!-- testimonial -->
                            </div><!-- Cell /-->
                     
							
							
							<div class="large-12 medium-12 small-12 cell">
                                <div class="testimonial-text">
                                  <img src="assets/images/help/our-staff/male.jpg" alt="Staff Images"/>  
                                    <h1> Marketing Executive </h1>
                                    <p>
<b>Position :-</b> Marketing Executive <br>
<b>Qualification:- </b> Graduate, 										
<b>Experience:- </b>   0-5 years, 
<b>Job location :-</b> Bilaspur,C.G <br> 
<b>Job Type :-</b> Regular   </p><br>


<table>
  <tr>
    <th>Sn.</th>
    <th>Position</th>
    <th>Experience</th>
    <th>Date</th>
    <th>Status</th>
    <th>Link to Apply </th>
  </tr>
  <tr>
    <td>1</td>
    <td>Marketing Executive  </td>
    <td>0-5 Year</td>
    <td>05-12-2020</td>
    <td>Active</td>
    <td> <a href="https://docs.google.com/forms/d/e/1FAIpQLSecS6lirfCq54G4GJIyFezhmUTv5KjgSujgfOZupMBm-5qL-A/viewform?usp=sf_link"> Apply Now </td>
  </tr>
  
</table>

                                    <h6>HR Department- <span>Mark Hospital</span></h6>

                                </div><!-- testimonial -->
                            </div><!-- Cell /-->							

							
							
							
							
							
							
							
							
							<div class="large-12 medium-12 small-12 cell">
                                <div class="testimonial-text">
                                  <img src="assets/images/help/our-staff/male.jpg" alt="Staff Images"/>  
                                    <h1> Staff Nurse/Ward Incharge </h1>
                                    <p>
<b>Position :-</b> B.Sc (Nursing), GNM, ANM <br>
<b>Qualification:- </b> Diploma in dialysis, 										
<b>Experience:- </b>   0-5 years, 
<b>Job location :-</b> Bilaspur,C.G <br> 
<b>Job Type :-</b> Regular   </p><br>


<table>
  <tr>
    <th>Sn.</th>
    <th>Position</th>
    <th>Experience</th>
    <th>Date</th>
    <th>Status</th>
    <th>Link to Apply </th>
  </tr>
  <tr>
    <td>1</td>
    <td>B.Sc (Nursing), GNM, ANM  </td>
    <td>0-5 Year</td>
    <td>27-11-2020</td>
    <td>Active</td>
    <td> <a href="https://docs.google.com/forms/d/e/1FAIpQLSecS6lirfCq54G4GJIyFezhmUTv5KjgSujgfOZupMBm-5qL-A/viewform?usp=sf_link"> Apply Now </td>
  </tr>
  
</table>

                                    <h6>HR Department- <span>Mark Hospital</span></h6>

                                </div><!-- testimonial -->
                            </div><!-- Cell /-->							

							
							
							
							
							
							
						 <div class="large-12 medium-12 small-12 cell">
                                <div class="testimonial-text">
                                  <img src="assets/images/help/our-staff/male.jpg" alt="Staff Images"/>  
                                    <h1> Dialysis Technician </h1>
                                    <p>
<b>Position :-</b> Dialysis Technician <br>
<b>Qualification:- </b> Diploma in dialysis, 										
<b>Experience:- </b>   0-5 years, 
<b>Job location :-</b> Bilaspur,C.G <br> 
<b>Job Type :-</b> Regular   </p><br>


<table>
  <tr>
    <th>Sn.</th>
    <th>Position</th>
    <th>Experience</th>
    <th>Date</th>
    <th>Status</th>
    <th>Link to Apply </th>
  </tr>
  <tr>
    <td>1</td>
    <td>Dialysis Technician </td>
    <td>0-5 Year</td>
    <td>27-11-2020</td>
    <td>Active</td>
    <td> <a href="https://docs.google.com/forms/d/e/1FAIpQLSecS6lirfCq54G4GJIyFezhmUTv5KjgSujgfOZupMBm-5qL-A/viewform?usp=sf_link"> Apply Now </td>
  </tr>
  
</table>

                                    <h6>HR Department- <span>Mark Hospital</span></h6>

                                </div><!-- testimonial -->
                            </div><!-- Cell /-->							

							
							
							
							
									
			 <div class="large-12 medium-12 small-12 cell">
                                <div class="testimonial-text">
                                  <img src="assets/images/help/our-staff/male.jpg" alt="Staff Images"/>  
                                    <h1> Consultant Physician </h1>
                                    <p>
<b>Position :-</b> Consultant Physician <br>
<b>Qualification:- </b> MD Medicine, 										
<b>Experience:- </b>  1 to 5 years, 
<b>Job location :-</b> Bilaspur,C.G <br> 
<b>Job Type :-</b> Regular   </p><br>


<table>
  <tr>
    <th>Sn.</th>
    <th>Position</th>
    <th>Experience</th>
    <th>Date</th>
    <th>Status</th>
    <th>Link to Apply </th>
  </tr>
  <tr>
    <td>1</td>
    <td>Consultant Physician </td>
    <td>1-5 Year</td>
    <td>18-11-2020</td>
    <td>Active</td>
    <td> <a href="https://docs.google.com/forms/d/e/1FAIpQLSecS6lirfCq54G4GJIyFezhmUTv5KjgSujgfOZupMBm-5qL-A/viewform?usp=sf_link"> Apply Now </td>
  </tr>
  
</table>

                                    <h6>HR Department- <span>Mark Hospital</span></h6>

                                </div><!-- testimonial -->
                            </div><!-- Cell /-->
       				
							
							
							
							
						
							
							
							
							
                            <div class="large-12 medium-12 small-12 cell">
                                <div class="testimonial-text">
                                  <img src="assets/images/help/our-staff/male.jpg" alt="Staff Images"/>  
                                    <h1>RMA Doctor </h1>
                                    <p>
<b>Position :-</b> Resident Medical Assistant <br>
<b>Experience:- </b>  1 to 5 years, 
<b>Job location :-</b> Bilaspur,C.G
<b>Job Type :-</b> Regular   </p><br>


<table>
  <tr>
    <th>Sn.</th>
    <th>Position</th>
    <th>Experience</th>
    <th>Date</th>
    <th>Status</th>
    <th>Link to Apply </th>
  </tr>
  <tr>
    <td>1</td>
    <td>RMA- Doctor </td>
    <td>1-5 Year</td>
    <td>07-11-2020</td>
    <td>Active</td>
    <td> <a href="https://docs.google.com/forms/d/e/1FAIpQLSecS6lirfCq54G4GJIyFezhmUTv5KjgSujgfOZupMBm-5qL-A/viewform?usp=sf_link"> Apply Now </td>
  </tr>
  
</table>

                                    <h6>HR Department- <span>Mark Hospital</span></h6>

                                </div><!-- testimonial -->
                            </div><!-- Cell /-->
                            
                            
						
	
					
				 
                            <div class="large-12 medium-12 small-12 cell">
                                <div class="testimonial-text">
                                  <img src="assets/images/help/our-staff/male.jpg" alt="Staff Images"/>  
                                    <h1>RMO Doctor </h1>
                                    <p> 
<b>Position :-</b> Resident Medical Officer <br>
<b>Experience:-</b>  1 to 5 years, 
<b>Job Location -</b> Bilaspur, C.G.
<b>Job Type -</b>Regular   </p><br>


<table>
  <tr>
    <th>Sn.</th>
    <th>Position</th>
    <th>Experience</th>
    <th>Date</th>
    <th>Status</th>
    <th>Link to Apply </th>
  </tr>
  <tr>
    <td>1</td>
    <td>RMO- Doctor </td>
    <td>1-5 Years</td>
    <td>07-11-2020</td>
    <td>Active</td>
    <td> <a href="https://docs.google.com/forms/d/e/1FAIpQLSecS6lirfCq54G4GJIyFezhmUTv5KjgSujgfOZupMBm-5qL-A/viewform?usp=sf_link"> Apply Now </td>
  </tr>
  
</table>

                                    <h6>HR Department- <span>Mark Hospital</span></h6>

                                </div><!-- testimonial -->
                            </div><!-- Cell /-->
						</div>
                    
						</div>
                    <div class="large-3 medium-5 small-12 cell sidebar">
                        <div class="widget">
                        	

<iframe src="https://docs.google.com/forms/d/e/1FAIpQLScAqcCfBrTWP7EQAQcC_jSWnZ4dfx4PAkoi2OSX7zBhNPKCmw/viewform?embedded=true" width="640" height="950" frameborder="0" marginheight="0" marginwidth="0">Loading…</iframe>










    					</div><!-- Widget /-->
                    </div><!-- Sidebar /-->
                    
                </div><!-- Grid Container /-->
            </div><!-- padding-between /-->
                    
        </div>
        <!-- Testimonials /-->
    <!-- Form Section /-->
       
<?php include('includes/footer.php'); ?>