<?php include('includes/header.php'); ?>
        <div class="title-section dark-bg module">
            
            <div class="grid-container grid-x grid-padding-x">

                <div class="small-12 cell">
                    <h1>About Our Director</h1>
                </div><!-- Top Row /-->
<!--
                <div class="small-12 cell">
                    <ul class="breadcrumbs">
                        <li><a href="#">Home</a></li>
                        <li class="disabled">Gene Splicing</li>
                        <li><span class="show-for-sr">Current: </span> Cloning</li>
                    </ul>
                    --><!-- Breadcrumbs /-->
                </div><!-- Bottom Row /-->

            </div><!-- Row /-->
            
        </div>
		<!-- Title Section Ends /-->
        
        <div class="why-chose-us module">
        	
            <div class="section-title">
                <h2>About Director</h2>
                <p>DR. KAMLESH MAURYA
                <p>DIRECTOR <br> MBBS, MS, DNB (GENITO URIN. SURG.)<br> Urology</p></p>
            </div><!-- Section Title /-->
            
            <div class="grid-container grid-x grid-padding-x">
            	
            	<div class="large-5 medium-12 small-12 cell">
                	<ul class="accordion" data-accordion data-deep-link="true" data-update-history="true" data-deep-link-smudge="500" id="deeplinked-accordion">
                    	<li class="accordion-item is-active" data-accordion-item>
                            <a href="#" class="accordion-title">About Dr.Kamlesh Maurya</a>
                            <div class="accordion-content" data-tab-content id="deeplink1">
                            Need this details
                            </div>
                        </li>
                        <li class="accordion-item " data-accordion-item>
                            <a href="#" class="accordion-title">PROFESSIONAL EXCELLENCE</a>
                            <div class="accordion-content" data-tab-content id="deeplink2">
                             Neet this details
                            </div>
                        </li>
                        <li class="accordion-item" data-accordion-item>
                            <a href="#" class="accordion-title">EXPERTISE</a>
                            <div class="accordion-content" data-tab-content id="deeplink3">
                            1. Upper urinary tract Endourology <br>
2.  Reconstructive Urology<br>
3.  Female Urology<br>
4.  Laparoscopic Surgery <br>
5.  Surgery by Holmium Laser <br>
6.  Prostate surgeries by Diode Laser
                            </div>
                        </li>
                        <li class="accordion-item" data-accordion-item>
                            <a href="#" class="accordion-title">MEMBERSHIP</a>
                            <div class="accordion-content" data-tab-content id="deeplink4">
                             Need details 
                            </div>
                        </li>
                    </ul><!-- Cccordion /-->
                </div><!-- cell /-->
                
                <div class="large-7 medium-12 small-12 cell">
                <img src="assets/images/help/drkamlesh.jpg" alt="" />
                	
                </div><!-- cell /-->
                
            </div><!-- Grid Container /-->
            
        </div>
        <!-- Why Chose Us /-->

<?php include('includes/footer.php'); ?>