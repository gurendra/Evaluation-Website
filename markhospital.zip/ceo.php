<?php include('includes/header.php'); ?>      
        <div class="title-section dark-bg module">
            
            <div class="grid-container grid-x grid-padding-x">

                <div class="small-12 cell">
                    <h1>About Our CEO</h1>
                </div><!-- Top Row /-->
<!--
                <div class="small-12 cell">
                    <ul class="breadcrumbs">
                        <li><a href="#">Home</a></li>
                        <li class="disabled">Gene Splicing</li>
                        <li><span class="show-for-sr">Current: </span> Cloning</li>
                    </ul>
                    --><!-- Breadcrumbs /-->
                </div><!-- Bottom Row /-->

            </div><!-- Row /-->
            
        </div>
        <!-- Title Section Ends /-->
        
        <div class="why-chose-us module">
            
            <div class="section-title">
                <h2>About CEO</h2>
                <p>DR. RENU BALA MAURYA
                <p>CEO <br> BDS, DENTAL & MAXILLO FACIAL SURGEON</p></p>
            </div><!-- Section Title /-->
            
            <div class="grid-container grid-x grid-padding-x">
                
                <div class="large-5 medium-12 small-12 cell">
                    <ul class="accordion" data-accordion data-deep-link="true" data-update-history="true" data-deep-link-smudge="500" id="deeplinked-accordion">
                        <li class="accordion-item is-active" data-accordion-item>
                            <a href="#" class="accordion-title">About Dr.Renu Bala Maurya</a>
                            <div class="accordion-content" data-tab-content id="deeplink1">
                            Need this details
                            </div>
                        </li>
                        <li class="accordion-item " data-accordion-item>
                            <a href="#" class="accordion-title">PROFESSIONAL EXCELLENCE</a>
                            <div class="accordion-content" data-tab-content id="deeplink2">
                             Neet this details
                            </div>
                        </li>
                        <li class="accordion-item" data-accordion-item>
                            <a href="#" class="accordion-title">EXPERTISE</a>
                            <div class="accordion-content" data-tab-content id="deeplink3">
                            Need details 
                            </div>
                        </li>
                        <li class="accordion-item" data-accordion-item>
                            <a href="#" class="accordion-title">MEMBERSHIP</a>
                            <div class="accordion-content" data-tab-content id="deeplink4">
                             Need details 
                            </div>
                        </li>
                    </ul><!-- Cccordion /-->
                </div><!-- cell /-->
                
                <div class="large-7 medium-12 small-12 cell">
                <img src="assets/images/help/drrenubala.png" alt="" />
                    
                </div><!-- cell /-->
                
            </div><!-- Grid Container /-->
            
        </div>
        <!-- Why Chose Us /-->
        <div class="footer">

        	<!--
        	<div class="call-to-action dark-bg grey-bg">
        		
        		<div class="grid-container grid-x grid-padding-x">
        			
                    <div class="large-12 medium-12 small-12 cell">
                        <div class="call-to-action-text">
                            <img src="assets/images/help/icons/ribbon.png" alt="Ribbon"/>
                            <h2>Its For your Great Skin!</h2>
                            <p>Crown quis lectus et mauris commodo blandit. Morbi rutrum libero eget nibh facilisis sollicitudin.</p>
                            <a class="button button-second secondary">fix an appointment</a>
                        </div><!-- Form/-->
                    </div><!-- cell /-->
                	
                </div><!-- Grid Container /-->
        		
        	</div>
        
<?php include('includes/footer.php'); ?>