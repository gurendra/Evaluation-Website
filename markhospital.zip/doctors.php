<?php include('includes/header.php'); ?>
        
        <div class="title-section dark-bg module">
            
            <div class="grid-container grid-x grid-padding-x">

                <div class="small-12 cell">
                    <h1>Our Doctors Team</h1>
                </div><!-- Top Row /-->

                

            </div><!-- Row /-->
            
        </div>
		<!-- Title Section Ends /-->
        
        <div class="our-staff module">
        
        	<div class="grid-container grid-x grid-padding-x">
            	
                <div class="large-3 medium-6 small-12 cell">
                    <div class="staff-box hover-wrap">
                        <div class="hover-img">
                            <img src="assets/images/help/our-staff/drkamles.jpg" alt="Staff Images"/>
                             <!--
                            <div class="staff-detail hover-info">
                            
                                <a href="#" class="button primary">Know More</a>
                               
                            </div>
                             -->
                        </div>
                        <div class="staff-text hover-bottom">
                            <h6><a href="#">DR. KAMLESH MAURYA</a></h6>
                            <p> MBBS, MS, DNB (GENITO URIN. SURG.) <p>Department of Urology</p>
                        </div>
                    </div><!-- Service Box /-->
                </div><!-- Cell /-->
                
                <div class="large-3 medium-6 small-12 cell">
                    <div class="staff-box hover-wrap">
                        <div class="hover-img">
                            <img src="assets/images/help/our-staff/drrenubala.jpg" alt="Staff Images"/>
                            <!--
                            <div class="staff-detail hover-info">
                            
                                <a href="#" class="button primary">Know More</a>
                               
                            </div>
                             -->
                        </div>
                        <div class="staff-text hover-bottom">
                            <h6><a href="#"> DR. RENU BALA MAURYA</a></h6>
                            <p> BDS, CONSULTANT DOCTOR AND COSMETIC SURGON <p> Department of Dentalogy </p>
                        </div>
                    </div><!-- Service Box /-->
                </div><!-- Cell /-->

                <div class="large-3 medium-6 small-12 cell">
                    <div class="staff-box hover-wrap">
                        <div class="hover-img">
                            <img src="assets/images/help/our-staff/drmamta.jpg" alt="Staff Images"/>
                            <!--
                            <div class="staff-detail hover-info">
                            
                                <a href="#" class="button primary">Know More</a>
                               
                            </div>
                             -->
                        </div>
                        <div class="staff-text hover-bottom">
                            <h6><a href="#">DR. MAMTA MINJ</a></h6>
                            <p>MBBS, MS <p>Department of Ophthalmology</p>
                        </div>
                    </div><!-- Service Box /-->
                </div><!-- Cell /-->

                <div class="large-3 medium-6 small-12 cell">
                    <div class="staff-box hover-wrap">
                        <div class="hover-img">
                            <img src="assets/images/help/our-staff/male.jpg" alt="Staff Images"/>
                            <!--
                            <div class="staff-detail hover-info">
                            
                                <a href="#" class="button primary">Know More</a>
                               
                            </div>
                             -->
                        </div>
                        <div class="staff-text hover-bottom">
                            <h6><a href="#">DR. ANURANJAN KUJUR</a></h6>
                            <p>MBBS, DA <p> Department of Anaesthesiology </p>
                        </div>
                    </div><!-- Service Box /-->
                </div><!-- Cell /-->
                
                <div class="large-3 medium-6 small-12 cell">
                    <div class="staff-box hover-wrap">
                        <div class="hover-img">
                        <br>
                        <br>

                            <img src="assets/images/help/our-staff/male.jpg" alt="Staff Images"/>
 <!--
                            <div class="staff-detail hover-info">
                            
                                <a href="#" class="button primary">Know More</a>
                               
                            </div>
                             -->
                        </div>

                        <div class="staff-text hover-bottom">
                            <h6><a href="#">DR. RAVINDRA BAGDE</a></h6>
                            <p>MBBS, MD <p>Department of Paediatrics</p>
                        </div>
                    </div><!-- Service Box /-->
                </div><!-- Cell /-->


                <div class="large-3 medium-6 small-12 cell">
                    <div class="staff-box hover-wrap">
                        <div class="hover-img">
                        <br>
                        <br>
                            <img src="assets/images/help/our-staff/drashish.jpg" alt="Staff Images"/>
 <!--
                            <div class="staff-detail hover-info">
                            
                                <a href="#" class="button primary">Know More</a>
                               
                            </div>
                             -->
                        </div>

                        <div class="staff-text hover-bottom">
                            <h6><a href="#">DR. ASHISH PUROHIT</a></h6>
                            <p>MD, DM <p>Department of Nephrology</p>
                        </div>
                    </div><!-- Service Box /-->
                </div><!-- Cell /-->


                <div class="large-3 medium-6 small-12 cell">
                    <div class="staff-box hover-wrap">
                        <div class="hover-img">
                        <br>
                        <br>
                            <img src="assets/images/help/our-staff/male.jpg" alt="Staff Images"/>
 <!--
                            <div class="staff-detail hover-info">
                            
                                <a href="#" class="button primary">Know More</a>
                               
                            </div>
                             -->
                        </div>

                        <div class="staff-text hover-bottom">
                            <h6><a href="#">DR. MANOJ RATHORE</a></h6>
                            <p>MBBS, D.Ortho<p>Department of Orthopedics</p>
                        </div>
                    </div><!-- Service Box /-->
                </div><!-- Cell /-->
                <br>
                <br>
                <div class="large-3 medium-6 small-12 cell">
                    <div class="staff-box hover-wrap">
                        <div class="hover-img">
                        <br>
                        <br>
                            <img src="assets/images/help/our-staff/male.jpg" alt="Staff Images"/>
                             <!--
                            <div class="staff-detail hover-info">
                            
                                <a href="#" class="button primary">Know More</a>
                               
                            </div>
                             -->
                        </div>
                        <div class="staff-text hover-bottom">
                            <h6><a href="#">DR. PRADEEP SONI</a></h6>
                            <p>MBBS, MS <p>Department of General Surgery</p>
                        </div>
                    </div><!-- Service Box /-->
                </div><!-- Cell /-->
            	
            </div><!-- Grid Container /-->
        
        </div>
        <!-- Our Staff /-->
        
        
<?php include('includes/footer.php'); ?>